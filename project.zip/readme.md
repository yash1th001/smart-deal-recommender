Dependenices of this project


Python 3.10+

pandas

numpy

matplotlib

seaborn

scikit-learn

xgboost


Running the project file : 

1. Install the required libraries 

pip install pandas numpy matplotlib seaborn scikit-learn xgboost 

execute the above command or install each one at a time

2. jupyter notebook sample.ipynb 

execute this in terminal

or if using the vscode press run all to execute all cells at a time


